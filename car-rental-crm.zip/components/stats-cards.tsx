import { TrendingUp } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"

export function StatsCards() {
  return (
    <>
      <Card className="overflow-hidden">
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 shrink-0">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <rect x="1" y="3" width="15" height="13"></rect>
                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                <circle cx="5.5" cy="18.5" r="2.5"></circle>
                <circle cx="18.5" cy="18.5" r="2.5"></circle>
              </svg>
            </div>
            <div>
              <div className="text-2xl font-bold">42</div>
              <div className="text-sm text-muted-foreground">On route vehicles</div>
              <div className="mt-1 flex items-center text-sm font-medium text-green-500">
                <TrendingUp className="mr-1 h-4 w-4" />
                +18.2% than last week
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Other stats cards with the same responsive layout */}
    </>
  )
}

