"use client"

import { useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ChevronDown, Plus } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent } from "@/components/ui/sheet"

interface SidebarProps {
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

export function Sidebar({ open, onOpenChange }: SidebarProps) {
  const pathname = usePathname()

  // Close sidebar when route changes on mobile
  useEffect(() => {
    if (open) {
      onOpenChange?.(false)
    }
  }, [open, onOpenChange])

  const sidebarContent = (
    <>
      <div className="flex h-14 items-center px-4 border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <div className="h-6 w-6">
            <svg viewBox="0 0 24 24" className="h-6 w-6 text-primary">
              <path fill="currentColor" d="M12 2L2 12h3v8h14v-8h3L12 2zm0 4.5l4.5 4.5H15v6H9v-6H7.5L12 6.5z" />
            </svg>
          </div>
          <span className="text-xl">Vuexy</span>
        </Link>
        <Button variant="ghost" size="icon" className="ml-auto">
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      <ScrollArea className="flex-1 px-2 py-2">
        <nav className="grid gap-1">
          <div className="py-2">
            <div className="flex items-center justify-between px-3 py-1.5">
              <Link
                href="#"
                className={cn(
                  "group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                  pathname === "/dashboards" && "bg-primary/10 text-primary",
                )}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
                <span>Dashboards</span>
                <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium text-white">
                  5
                </span>
                <ChevronDown className="ml-1 h-4 w-4 text-muted-foreground" />
              </Link>
            </div>

            <div className="grid gap-1 pl-6">
              <Link
                href="#"
                className="group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
              >
                <div className="flex h-2 w-2 items-center justify-center">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground"></div>
                </div>
                <span>CRM</span>
              </Link>

              <Link
                href="#"
                className="group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
              >
                <div className="flex h-2 w-2 items-center justify-center">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground"></div>
                </div>
                <span>Analytics</span>
              </Link>

              <Link
                href="#"
                className="group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
              >
                <div className="flex h-2 w-2 items-center justify-center">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground"></div>
                </div>
                <span>eCommerce</span>
              </Link>

              <Link
                href="#"
                className="group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
              >
                <div className="flex h-2 w-2 items-center justify-center">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground"></div>
                </div>
                <span>Academy</span>
              </Link>

              <Link
                href="#"
                className="group flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium bg-primary/20 text-primary"
              >
                <div className="flex h-2 w-2 items-center justify-center">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                </div>
                <span>Logistics</span>
              </Link>
            </div>
          </div>

          <div className="py-2">
            <div className="px-3 py-1">
              <h3 className="text-xs font-medium text-muted-foreground">APPS & PAGES</h3>
            </div>
            <div className="grid gap-1">{/* Apps & Pages links - Same as before */}</div>
          </div>
        </nav>
      </ScrollArea>
    </>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-screen w-64 flex-col bg-sidebar text-sidebar-foreground border-r">
        {sidebarContent}
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="left" className="w-64 p-0">
          {sidebarContent}
        </SheetContent>
      </Sheet>
    </>
  )
}

