import { MoreVertical } from "lucide-react"
import { cn } from "@/lib/utils"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface OrdersByCountriesProps {
  className?: string
}

export function OrdersByCountries({ className }: OrdersByCountriesProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-lg font-medium">Orders by Countries</CardTitle>
          <p className="text-sm text-muted-foreground">62 deliveries in progress</p>
        </div>
        <Button variant="ghost" size="icon">
          <MoreVertical className="h-4 w-4" />
          <span className="sr-only">More options</span>
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="new" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="new">New</TabsTrigger>
            <TabsTrigger value="preparing">Preparing</TabsTrigger>
            <TabsTrigger value="shipping">Shipping</TabsTrigger>
          </TabsList>
          <TabsContent value="new" className="pt-4">
            <div className="h-[180px] flex items-center justify-center">
              <Button className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600">
                Buy Now
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="preparing" className="pt-4">
            <div className="h-[180px] flex items-center justify-center">
              <p className="text-muted-foreground">No orders in preparation</p>
            </div>
          </TabsContent>
          <TabsContent value="shipping" className="pt-4">
            <div className="h-[180px] flex items-center justify-center">
              <p className="text-muted-foreground">No orders shipping</p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

