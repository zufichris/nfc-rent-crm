"use client"

import { useResizeObserver } from "@/hooks/use-resize-observer"
import { MoreVertical } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export function VehicleOverview() {
  const [ref, size] = useResizeObserver()

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Vehicle Overview</CardTitle>
        <Button variant="ghost" size="icon">
          <MoreVertical className="h-4 w-4" />
          <span className="sr-only">More options</span>
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full" ref={ref}>
          <div className="min-w-[400px]">
            <div className="grid grid-cols-4 gap-2 text-sm">
              <div className="text-center">On the way</div>
              <div className="text-center">Unloading</div>
              <div className="text-center">Loading</div>
              <div className="text-center">Waiting</div>
            </div>

            <div className="mt-2 flex h-2 w-full overflow-hidden rounded-full bg-muted">
              <div className="bg-blue-500" style={{ width: "39.7%" }}></div>
              <div className="bg-indigo-500" style={{ width: "28.3%" }}></div>
              <div className="bg-cyan-500" style={{ width: "17.4%" }}></div>
              <div className="bg-slate-700 dark:bg-slate-500" style={{ width: "14.6%" }}></div>
            </div>

            <div className="mt-6 space-y-4">
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center gap-3">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <rect x="1" y="3" width="15" height="13"></rect>
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                    <circle cx="5.5" cy="18.5" r="2.5"></circle>
                    <circle cx="18.5" cy="18.5" r="2.5"></circle>
                  </svg>
                  <span>On the way</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="whitespace-nowrap">2hr 10min</span>
                  <span className="font-medium">39.7%</span>
                </div>
              </div>

              {/* Other status items remain the same */}
            </div>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

