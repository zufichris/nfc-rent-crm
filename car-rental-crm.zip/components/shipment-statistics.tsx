"use client"

import { useState } from "react"
import { ChevronDown, MoreVertical } from "lucide-react"
import { useResizeObserver } from "@/hooks/use-resize-observer"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function ShipmentStatistics() {
  const [month, setMonth] = useState("January")
  const [ref, size] = useResizeObserver()

  // Responsive chart sizing
  const chartHeight = size?.width ? Math.min(300, Math.max(200, size.width * 0.6)) : 300

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-lg font-medium">Shipment Statistics</CardTitle>
          <p className="text-sm text-muted-foreground">Total number of deliveries 23.8k</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8">
            {month}
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-4 w-4" />
            <span className="sr-only">More options</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div ref={ref} style={{ height: chartHeight }} className="w-full">
          <div className="flex h-full items-end gap-2">
            {[35, 45, 30, 40, 30, 45, 35, 40, 35, 30].map((height, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div className="relative w-full">
                  <div
                    className="w-full rounded-sm bg-orange-400"
                    style={{ height: `${(height / 50) * (chartHeight - 40)}px` }}
                  />
                  {i % 2 === 0 && (
                    <div className="absolute -top-2 left-1/2 h-4 w-4 -translate-x-1/2 rounded-full bg-indigo-500 border-2 border-white dark:border-gray-800" />
                  )}
                  {i % 2 === 1 && (
                    <div className="absolute -top-4 left-1/2 h-4 w-4 -translate-x-1/2 rounded-full bg-indigo-500 border-2 border-white dark:border-gray-800" />
                  )}
                </div>
                <div className="text-xs text-muted-foreground whitespace-nowrap">{i + 1} Jan</div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-orange-400" />
              <span className="text-sm">Shipment</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-indigo-500" />
              <span className="text-sm">Delivery</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

