"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { StatsCards } from "@/components/stats-cards"
import { VehicleOverview } from "@/components/vehicle-overview"
import { ShipmentStatistics } from "@/components/shipment-statistics"
import { DeliveryPerformance } from "@/components/delivery-performance"
import { DeliveryExceptions } from "@/components/delivery-exceptions"
import { OrdersByCountries } from "@/components/orders-by-countries"
import { cn } from "@/lib/utils"

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar open={sidebarOpen} onOpenChange={setSidebarOpen} />
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <DashboardHeader onMenuClick={() => setSidebarOpen(true)} />
        <main
          className={cn(
            "flex-1 overflow-y-auto",
            "px-4 py-4 space-y-4",
            "sm:px-6 sm:py-6 sm:space-y-6",
            "lg:px-8 lg:py-8 lg:space-y-8",
          )}
        >
          <div className="grid gap-4 sm:gap-6 lg:gap-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCards />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <VehicleOverview />
              <ShipmentStatistics />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <DeliveryPerformance />
              <DeliveryExceptions />
              <OrdersByCountries className="md:col-span-2 lg:col-span-1" />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

