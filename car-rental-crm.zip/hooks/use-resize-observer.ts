"use client"

import { useCallback, useEffect, useState } from "react"

export function useResizeObserver<T extends HTMLElement>() {
  const [size, setSize] = useState<DOMRectReadOnly>()
  const [ref, setRef] = useState<T | null>(null)

  const handleResize = useCallback((entries: ResizeObserverEntry[]) => {
    const entry = entries[0]
    if (entry) {
      setSize(entry.contentRect)
    }
  }, [])

  useEffect(() => {
    if (!ref) return

    const observer = new ResizeObserver(handleResize)
    observer.observe(ref)

    return () => {
      observer.disconnect()
    }
  }, [ref, handleResize])

  return [setRef, size] as const
}

